<h1>Categories</h1>
<ul>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <?php echo e($category->name); ?>

        -
        <a href="/admin/categories/<?php echo e($category->id); ?>/edit">edit</a>

        <form action="/admin/categories/<?php echo e($category->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit">delete</button>
        </form>
    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<a href="/admin/categories/create">Add category</a><?php /**PATH C:\Users\nguye\Herd\cloud-nine\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>