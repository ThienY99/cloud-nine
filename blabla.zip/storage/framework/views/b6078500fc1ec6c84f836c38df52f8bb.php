<div>
    <nav style="background: #8B7355; padding: 12px 24px; display: flex; justify-content: space-between;">
        <a href="<?php echo e(route('welcome')); ?>" style="color: white; font-weight: bold;">Cloud 9 Café</a>
        <div style="display: flex; gap: 16px;">
            <a href="<?php echo e(route('categories.index')); ?>" style="color: white;">Menu</a>
            <a href="<?php echo e(route('faqs.index')); ?>" style="color: white;">FAQ</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>" style="color: white;">Dashboard</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="color: white; background: none; border: none; cursor: pointer;">Logout</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" style="color: white;">Login</a>
                <a href="<?php echo e(route('register')); ?>" style="color: white;">Register</a>
            <?php endif; ?>
        </div>
    </nav>

    <main style="max-width: 900px; margin: 24px auto; padding: 0 16px;">
        <?php echo e($slot); ?>

    </main>

    <footer style="background: #8B7355; color: white; text-align: center; padding: 16px; margin-top: 40px;">
        © Cloud 9 Café
    </footer>
</div><?php /**PATH C:\Users\nguye\Herd\cloud-nine\resources\views/components/site-layout.blade.php ENDPATH**/ ?>