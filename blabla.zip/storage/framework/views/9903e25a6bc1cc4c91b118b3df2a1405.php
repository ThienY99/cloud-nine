<h1>FAQs</h1>
<ul>
<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($faq->question); ?></li>
    <li>
        <?php echo e($faq->question); ?>

        -
        <a href="/admin/faqs/<?php echo e($faq->id); ?>/edit">edit</a>

        <form action="/admin/faqs/<?php echo e($faq->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit">delete</button>
        </form>
    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<a href="/admin/faqs/create">Add faq</a>
<?php /**PATH C:\Users\nguye\Herd\cloud-nine\resources\views/admin/faqs/index.blade.php ENDPATH**/ ?>