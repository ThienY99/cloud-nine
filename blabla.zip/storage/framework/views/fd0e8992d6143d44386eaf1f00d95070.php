<form action="/admin/categories" method="post">
    <?php echo csrf_field(); ?>


    <?php if (isset($component)) { $__componentOriginal5c9f6fee92214136570f327b8f751130 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c9f6fee92214136570f327b8f751130 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-textinput','data' => ['name' => 'name','label' => 'Category name','placeholder' => 'category name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-textinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Category name','placeholder' => 'category name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c9f6fee92214136570f327b8f751130)): ?>
<?php $attributes = $__attributesOriginal5c9f6fee92214136570f327b8f751130; ?>
<?php unset($__attributesOriginal5c9f6fee92214136570f327b8f751130); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c9f6fee92214136570f327b8f751130)): ?>
<?php $component = $__componentOriginal5c9f6fee92214136570f327b8f751130; ?>
<?php unset($__componentOriginal5c9f6fee92214136570f327b8f751130); ?>
<?php endif; ?>


    <button type="submit">Create</button>

</form><?php /**PATH C:\Users\nguye\Herd\cloud-nine\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>